def matrix_multiply(a, b, mod):
    
    result = [[0, 0], [0, 0]]
    for i in range(2):
        for j in range(2):
            for k in range(2):
                result[i][j] += (a[i][k] * b[k][j]) % mod
                result[i][j] %= mod
    return result

def matrix_power(matrix, exp, mod):
    
    if exp == 1:
        return matrix
    if exp % 2 == 0:
        half_pow = matrix_power(matrix, exp // 2, mod)
        return matrix_multiply(half_pow, half_pow, mod)
    else:
        return matrix_multiply(matrix, matrix_power(matrix, exp - 1, mod), mod)

def calculate_fn_mod_m(n, a, b, f0, f1, m):
    if n == 0:
        return f0
    if n == 1:
        return f1
     
    transformation_matrix = [[a, b], [1, 0]]
    
    result_matrix = matrix_power(transformation_matrix, n - 1, m)
    
    fn = (f1 * result_matrix[0][0] + f0 * result_matrix[0][1]) % m
    
    return fn

# input
n, a, b, f0, f1, m = map(int, input().split())

# calculate fn mod m
result = calculate_fn_mod_m(n, a, b, f0, f1, m)

# output
print(result)
