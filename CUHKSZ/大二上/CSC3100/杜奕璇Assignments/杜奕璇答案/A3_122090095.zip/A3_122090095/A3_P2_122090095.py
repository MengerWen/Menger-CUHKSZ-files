class Node:
    def __init__(self, key, parent):
        self.key = key
        self.left = None
        self.right = None
        self.parent = parent


def insert(root, key, parent=None):
    if root is None:
        return Node(key, parent), Node(key, parent)
    else:
        if key < root.key:
            root.left, new_node = insert(root.left, key, root)
        else:
            root.right, new_node = insert(root.right, key, root)
    return root, new_node


def find_closest(new_node):
    diff1 = new_node.key-new_node.parent.key
    if diff1<=0:
        now = new_node
        while now.parent and now.key<=now.parent.key:
            now = now.parent
        if now.parent:
            diff2 = new_node.key-now.parent.key
            return min(diff2, -diff1)
    else:
        now = new_node
        while now.parent and now.key>=now.parent.key:
            now = now.parent
        if now.parent:
            diff2 = now.parent.key-new_node.key
            return min(diff2, diff1)
    return abs(diff1)


def closest_adj_price_bst(sequence):
    min_adj_diff = float('inf')
    for i in range(len(sequence) - 1):
        adj_diff = abs(sequence[i] - sequence[i + 1])
        min_adj_diff = min(min_adj_diff, adj_diff)
    return min_adj_diff


def closest_price_bst(root, min_diff):
    if root is not None:
        min_diff = closest_price_bst(root.left, min_diff)

        # Check predecessor
        if root.left is not None:
            current_diff = abs(root.key - find_max(root.left).key)
            min_diff = min(min_diff, current_diff)

        # Check successor
        if root.right is not None:
            current_diff = abs(root.key - find_min(root.right).key)
            min_diff = min(min_diff, current_diff)

        min_diff = closest_price_bst(root.right, min_diff)

    return min_diff


def find_min(node):
    while node.left is not None:
        node = node.left
    return node


def find_max(node):
    while node.right is not None:
        node = node.right
    return node


def perform_operations_bst(sequence, operations):
    root = None
    for price in sequence:
        root, _ = insert(root, price)
    result = []
    min_diff1 = closest_adj_price_bst(sequence)
    min_diff2 = closest_price_bst(root, float('inf'))
    for op in operations:
        if op[0] == "BUY":
            price = op[1]
            min_diff1 = min(min_diff1,abs(price-sequence[-1]))
            _, new_node = insert(root, price)
            min_diff2 = min(min_diff2, find_closest(new_node))
            sequence.append(price)
        elif op == "CLOSEST_ADJ_PRICE":
            result.append(min_diff1)
        elif op == "CLOSEST_PRICE":
            result.append(min_diff2)

    return result


if __name__ == "__main__":
    n, m = map(int, input().split())
    sequence = list(map(int, input().split()))
    operations = []
    for _ in range(m):
        operation = input().split()
        if operation[0] == "BUY":
            operations.append(("BUY", int(operation[1])))
        else:
            operations.append(operation[0])

    # Using BST
    result_bst = perform_operations_bst(sequence, operations)

    # Print the output
    for rb in result_bst:
        print(rb)