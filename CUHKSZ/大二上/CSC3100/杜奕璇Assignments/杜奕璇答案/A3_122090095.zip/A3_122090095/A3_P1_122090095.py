import sys
sys.setrecursionlimit(2000000)
class Node:
    def __init__(self):
        self.childList = []
        self.key = 0
        self.color = 0
        self.dis = 0

class Tree:
    def add_child(self, parent, child):
        parent.childList.append(child)

    def num_black(self, root, black_point):
        black = 0
        num_child = len(root.childList)

        if num_child == 0:
            if root.color == 1:
                black_point[root.key] = 1
                return 1
            else:
                return 0

        if black_point[root.key] != 0:
            return black_point[root.key]

        for i in range(num_child):
            black += self.num_black(root.childList[i], black_point)

        if root.color == 1:
            black += 1

        black_point[root.key] = black
        return black

    def distance(self, arr, black_point, total):
        distance = 0
        for i in range(2, len(black_point)):
            son_black = black_point[i]
            distance += son_black * (total - son_black) * arr[i].dis

        return distance


tree = Tree()

num = int(input())
arr = [Node() for _ in range(num + 1)] 
color_values = list(map(int, input().split()))

for i in range(1, num + 1):
    arr[i].color = color_values[i - 1]
    arr[i].key = i

for i in range(2, num + 1):
    parent, arr[i].dis = map(int, input().split())
    tree.add_child(arr[parent], arr[i])

black_point = [0] * (num + 1)
total = tree.num_black(arr[1], black_point)  

print(tree.distance(arr, black_point, total))

