class Stack(object):
    def __init__(self):
        self.items = []
 
    def is_empty(self):
        return self.items == []
 
    def push(self, item):
        self.items.append(item)

    def top(self):
        if self.items:
            return self.items[-1]
        
    def pop(self):
        if not self.is_empty():
            return self.items.pop() 
        else:
            return None  

def play_game(players):
    stack = Stack()
    for _, h, d, i in players:
        if d == "U":
            stack.push((h,d,i))
        else:
            if stack.is_empty() or stack.top() ==(_,"D",_):
                stack.push((h,d,i))
            else:
                 while not stack.is_empty() and stack.top()[1] == "U" and h > stack.top()[0]:
                    h -= 1
                    stack.pop()
                 if stack.is_empty() or stack.top()[1] == "D":
                    stack.push((h, d, i))
                 elif h < stack.top()[0] and stack.top()[1] == "U":
                    h3, d3, i3 = stack.pop()   
                    h3 -= 1
                    stack.push((h3, d3, i3))
                 elif h == stack.top()[0]:
                    stack.pop()
                   
    # Sort players by their original index
    players = sorted(stack.items, key=lambda x: x[2])
    for h, _, _ in players:
        print(h)

n = int(input())
players = []

for i in range(n):
    p, h, d = input().split()
    players.append((int(p), int(h), d, i))
sortlist = sorted(players) 
play_game(sortlist)