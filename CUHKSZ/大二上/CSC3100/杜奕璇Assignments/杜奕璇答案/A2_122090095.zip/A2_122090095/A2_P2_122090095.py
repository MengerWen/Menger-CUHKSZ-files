# Function to calculate the largest treasure for a single query
def largest_treasure(query):
    n, depths = query
    left = [0] * n  # Initialize arrays to store the left and right boundaries of the treasure
    right = [0] * n
    stack = []  # Initialize a stack to keep track of the indices

    # Calculate the left boundaries
    for i in range(n):
        while stack and depths[i] <= depths[stack[-1]]:
            stack.pop()
        left[i] = stack[-1] + 1 if stack else 0
        stack.append(i)

    # Clear the stack for calculating right boundaries
    stack = []

    # Calculate the right boundaries
    for i in range(n - 1, -1, -1):
        while stack and depths[i] <= depths[stack[-1]]:
            stack.pop()
        right[i] = stack[-1] - 1 if stack else n - 1
        stack.append(i)

    max_treasure = 0
    for i in range(n):
        width = right[i] - left[i] + 1
        max_treasure = max(max_treasure, width * depths[i])

    return max_treasure

# Read the number of queries
T = int(input())

# Process each query and print the result
for _ in range(T):
    n = int(input())
    depths = list(map(int, input().split()))
    query = (n, depths)
    result = largest_treasure(query)
    print(result)
