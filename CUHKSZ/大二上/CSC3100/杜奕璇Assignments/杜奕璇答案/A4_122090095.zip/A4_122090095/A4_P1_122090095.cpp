#include <iostream>
#include <queue>
#include <vector>
#include <climits>
using namespace std;

vector<vector<char>> parse_grid(int m, int n) {
    vector<vector<char>> grid(m, vector<char>(n));
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cin >> grid[i][j];
        }
    }
    return grid;
}

struct Neighbor {
    Neighbor(int x, int y, char dir):x(x),y(y),dir(dir){};
    int x;
    int y;
    char dir;
};

vector<Neighbor> get_neighbors(int x, int y, int m, int n) {
    vector<Neighbor> neighbors;
    vector<pair<int, int>> directions = { {-1, 0}, {0, -1}, {1, 0}, {0, 1} };
    vector<char> chars = { 'w', 'a', 's', 'd' };
    for (int i = 0; i < 4; i++) {
        int nx = x + get<0>(directions[i]), ny = y + get<1>(directions[i]);
        if (nx >= 0 && nx < m && ny >= 0 && ny < n) {
            neighbors.emplace_back(Neighbor(nx, ny, chars[i]));
        }
    }
    return neighbors;
}

pair<int, int> find_position(const vector<vector<char>>& grid, char c) {
    for (int i = 0; i < grid.size(); i++) {
        for (int j = 0; j < grid[0].size(); j++) {
            if (grid[i][j] == c) {
                return { i, j };
            }
        }
    }
    return { -1, -1 };
}

int a_star(const vector<vector<char>>& grid, pair<int, int> start, pair<int, int> end, int m, int n) {
    priority_queue<pair<int, pair<int, int>>, vector<pair<int, pair<int, int>>>, greater<pair<int, pair<int, int>>>> heap;
    heap.push({ 0, start });

    vector<vector<bool>> visited(m, vector<bool>(n, false));
    vector<vector<int>> distances(m, vector<int>(n, INT_MAX));
    distances[start.first][start.second] = 0;

    while (!heap.empty()) {
        auto top = heap.top();
        int cost = top.first;
        pair<int, int> pos = top.second;
        heap.pop();

        int x = pos.first, y = pos.second;
        if (pos == end) {
            return cost;
        }

        if (visited[x][y]) {
            continue;
        }

        visited[x][y] = true;
        vector<Neighbor> neighbors = get_neighbors(x, y, m, n);
        for (int i = 0; i < neighbors.size();i++) {
            Neighbor neighbor = neighbors[i];
            int nx = neighbor.x;
            int ny = neighbor.y;
            char dir = neighbor.dir;
            int newCost = cost + (grid[x][y] != dir);
            if (distances[nx][ny] > newCost) {
                distances[nx][ny] = newCost;
                int priority = newCost;
                heap.push({ priority, {nx, ny} });
            }
        }
    }

    return INT_MAX;
}

int main() {

    int m, n;
    cin >> m >> n;

    vector<vector<char>> grid = parse_grid(m, n);

    auto start = find_position(grid, 'i');
    auto end = find_position(grid, 'j');

    int changes = a_star(grid, start, end, m, n);

    if (changes == INT_MAX) {
        cout << "-1\n";
    }
    else {
        cout << (changes - 1) << "\n";
    }

    return 0;
}