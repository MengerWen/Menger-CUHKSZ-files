def bfs_order(n, m, k, s, edges):
    graph = {i: [] for i in range(1, n + 1)}

    for edge in edges:
        u, v = edge
        graph[u].append(v)
        graph[v].append(u)

    for i in range(1, n + 1):
        neighbors = graph[i]
        for u in neighbors:
            for v in neighbors:
                if u != v and (u == k * v or v == k * u) and v not in graph[u]:
                    graph[u].append(v)
                    graph[v].append(u)

    visited = set()
    result = []

    queue = [s]
    visited.add(s)

    while queue:
        vertex = queue.pop(0)
        result.append(vertex)

        for neighbor in sorted(graph[vertex]):
            if neighbor not in visited:
                queue.append(neighbor)
                visited.add(neighbor)

    return result

# Sample Input 1
n, m, k, s = map(int, input().split())
edges = [tuple(map(int, input().split())) for _ in range(m)]

# Sample Output 1
result = bfs_order(n, m, k, s, edges)
print(" ".join(map(str, result)))
