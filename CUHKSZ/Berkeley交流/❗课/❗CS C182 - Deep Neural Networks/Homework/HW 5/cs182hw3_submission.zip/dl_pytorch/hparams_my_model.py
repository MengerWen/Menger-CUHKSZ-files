from argparse import Namespace

#######################################################################
# TODO: Design your own neural network
# Set hyperparameters here

# Hyperparameters for MyNeuralNetwork
# - epochs <= 10
# - steps = ceil(50000 / batch_size) * epochs  <= 20000
# - model params < 1,000,000 (satisfied by architecture)
#######################################################################


HP = Namespace(
    # training
    epochs=10,
    batch_size=128,          # steps/epoch ≈ 50000/128 ≈ 391; total ≈ 3910 <= 20000
    optim_type="adam",       # AdamW in get_optimizer
    lr=1e-3,
    momentum=0.9,            # used as beta1 for AdamW per notebook helper
    lr_decay=0.98,           # mild exponential decay
    l2_reg=5e-4,             # weight decay

    # model toggles
    do_batchnorm=True,
    p_dropout=0.2,
)

#######################################################################
