import torch
import torch.nn as nn
import torch.nn.functional as F


#######################################################################
# TODO: Design your own neural network
# You can define utility functions/classes here
#######################################################################
class ConvBNReLU(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, s=1, p=1, do_bn=True):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, kernel_size=k, stride=s, padding=p, bias=True)
        self.bn = nn.BatchNorm2d(out_ch) if do_bn else nn.Identity()
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
#######################################################################
# End of your code
#######################################################################


class MyNeuralNetwork(nn.Module):
    def __init__(self, do_batchnorm=False, p_dropout=0.0):
        super().__init__()
        self.do_batchnorm = do_batchnorm
        self.p_dropout = p_dropout

        #######################################################################
        # TODO: Design your own neural network
        #######################################################################
        # Stem + blocks (total params < 1e6)
        # Input: [B,3,32,32]
        self.block1 = ConvBNReLU(3, 48, do_bn=do_batchnorm)          # -> [B,48,32,32]
        self.block2 = ConvBNReLU(48, 96, do_bn=do_batchnorm)         # -> [B,96,32,32]
        self.pool1  = nn.MaxPool2d(2, 2)                             # -> [B,96,16,16]

        self.block3 = ConvBNReLU(96, 192, do_bn=do_batchnorm)        # -> [B,192,16,16]
        self.pool2  = nn.MaxPool2d(2, 2)                             # -> [B,192,8,8]

        self.block4 = ConvBNReLU(192, 256, do_bn=do_batchnorm)       # -> [B,256,8,8]

        # Global Average Pooling to 1x1 (size-agnostic & param-efficient)
        self.gap = nn.AdaptiveAvgPool2d((1, 1))                      # -> [B,256,1,1]

        # Classifier
        feat_dim = 256
        self.drop = nn.Dropout(p=p_dropout) if p_dropout > 0.0 else nn.Identity()
        self.fc   = nn.Linear(feat_dim, 100)
        #######################################################################
        # End of your code
        #######################################################################

    def forward(self, x):
        #######################################################################
        # TODO: Design your own neural network
        #######################################################################
        x = self.block1(x)
        x = self.block2(x); x = self.pool1(x)
        x = self.block3(x); x = self.pool2(x)
        x = self.block4(x)

        x = self.gap(x)                       # [B,256,1,1]
        x = torch.flatten(x, 1)               # [B,256]
        x = self.drop(x)
        x = self.fc(x)                        # [B,100]
        return x
        #######################################################################
        # End of your code
        #######################################################################
